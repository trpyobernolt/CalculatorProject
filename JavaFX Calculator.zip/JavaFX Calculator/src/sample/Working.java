package sample;

public class Working {
    public static String working = "0";
    public static StringBuilder expression = new StringBuilder();
}
